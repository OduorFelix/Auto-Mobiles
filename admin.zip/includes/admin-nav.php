                      <div class="menu" style="margin-top:11%;">
						<ul id="menu" >
						<li><a href="dashboard.php"><i class="fa fa-tachometer"></i> <span>Dashboard</span><div class="clearfix"></div></a></li>

						<li id="menu-academico" ><a href="#"><i class="fa fa-list-ul" aria-hidden="true"></i><span>Edit Pages</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
						<ul id="menu-academico-sub" >
							<li id="menu-academico-avaliacoes" ><a href="edit-home-page.php">Home</a></li>
							<li id="menu-academico-avaliacoes" ><a href="edit-hot-deals.php">Hot Deals</a></li>
							<li id="menu-academico-avaliacoes" ><a href="edit-new-arrivals.php">New Arrivals</a></li>
							<li id="menu-academico-avaliacoes" ><a href="edit-top-sales.php">Top Sells</a></li>
							</ul>
						</li>
							<li id="menu-academico" ><a href="orders.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i><span>Current Orders</span><div class="clearfix"></div></a></li>

							<li id="menu-academico" ><a href="messages.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i><span>Messages</span><div class="clearfix"></div></a></li>

				
							<li><a href="password-reset.php"><i class="fa fa-arrow-up"></i>  
							  <span>Change Password</span><div class="clearfix"></div></a></li>

							<li><a href="logout.php"><i class="fa fa-user" aria-hidden="true"></i>  
								<span>Logout</span><div class="clearfix"></div></a></li>

								  </ul>
								</div>