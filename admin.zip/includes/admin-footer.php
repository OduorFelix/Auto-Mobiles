		<footer id="footer">
			<!-- bottom footer -->
			<div id="bottom-footer" class="section text-center">
			<span class="copyright">
								Copyright &copy;
								JCT Motors Mombasa | All rights reserved | Designed by Hamnic Solutions.
							
							</span>
			</div>
			<!-- /bottom footer -->
		</footer>