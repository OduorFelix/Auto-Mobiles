<nav id="navigation">
			<!-- container -->
			<div class="container">
				<!-- responsive-nav -->
				<div id="responsive-nav">
					<!-- NAV -->
					<ul class="main-nav nav navbar-nav">
						<li class="active"><a href="index.php"><i class="fa fa-home"></i>  Home</a></li>
						<li><a href="about.php"><i class="fa fa-th"></i>  About Us</a></li>
						<li><a href="hot_deals.php"><i class="fa fa-th-list"></i> Hot Deals</a></li>
						<li><a href="new_arrivals.php"><i class="fa fa-th-list"></i> New Arrivals</a></li>
						<li><a href="top_selling.php"><i class="fa fa-th-list"></i> Top Sells</a></li>
						<li><a href="contact.php"><i class="fa fa-users"></i> Contacts</a></li>
					</ul>
					<!-- /NAV -->
				</div>
				<!-- /responsive-nav -->
			</div>
			<!-- /container -->
		</nav>